#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>

using namespace std;

const int n = 100;

void FCFS(int arrival[], int burst[], int context_switch, int finish_time[]);
void SRT(int arrival[], int burst[], int context_switch, int finish_time[]);
void RR(int arrival[], int burst[], int context_switch, int q, int finish_time[]);

void printGanttChart(int finish_time[]) {
    cout << "Gantt Chart:\n";
    for (int i = 0; i < n; i++) {
        cout << "|---P" << i + 1 << "---| ";
    }
    cout << "\n";
    cout << "0 /t";
    for (int i = 0; i < n; i++) {
        cout << finish_time[i] << "           ";
    }
    cout << "\n";
}

double calculateCPUUtilization(int finish_time[]) {
    double total_burst_time = finish_time[n - 1];
    double cpu_utilization = total_burst_time / finish_time[n - 1];
    return cpu_utilization * 100;
}

void FCFS(int arrival[], int burst[], int context_switch, int finish_time[]) {
    int waiting_time[n], turn_around_time[n];
    waiting_time[0] = 0;
    finish_time[0] = burst[0] + context_switch;
    for (int i = 1; i < n; i++) {
        waiting_time[i] = finish_time[i - 1] - arrival[i];
        finish_time[i] = finish_time[i - 1] + burst[i] + context_switch;
    }
}

void SRT(int arrival[], int burst[], int context_switch, int finish_time[], int waiting_time[], int turn_around_time[]) {
    int temp[n];
    for (int i = 0; i < n; i++)
        temp[i] = burst[i];
    int time = 0, index = 0;
    while (1) {
        int min_idx = -1, min_burst = 20;
        for (int i = 0; i < n; i++) {
            if (arrival[i] <= time && temp[i] < min_burst && temp[i] > 0) {
                min_idx = i;
                min_burst = temp[i];
            }
        }
        if (min_idx == -1)
            break;
        temp[min_idx]--;
        time++;
        if (temp[min_idx] == 0) {
            finish_time[index] = time;
            index++;
        }
    }
    for (int i = 0; i < n; i++) {
        waiting_time[i] = finish_time[i] - burst[i] - arrival[i];
        turn_around_time[i] = finish_time[i] - arrival[i];
    }
}

void RR(int arrival[], int burst[], int context_switch, int q, int finish_time[], int waiting_time[], int turn_around_time[]) {
    int temp[n];
    for (int i = 0; i < n; i++)
        temp[i] = burst[i];
    int time = 0, idx = 0;
    while (1) {
        int flag = 0;
        for (int i = 0; i < n; i++) {
            if (arrival[i] <= time && temp[i] > 0) {
                flag = 1;
                int run_time = min(q, temp[i]);
                temp[i] -= run_time;
                time += run_time;
                if (temp[i] == 0) {
                    finish_time[idx] = time;
                    idx++;
                }
            }
        }
        if (flag == 0)
            break;
    }
    for (int i = 0; i < n; i++) {
        waiting_time[i] = finish_time[i] - burst[i] - arrival[i];
        turn_around_time[i] = finish_time[i] - arrival[i];
    }
}


int main() {
    int arrival[n], burst[n];
    int context_switch, quantum;
    int finish_time[n] = { 0 };

    ifstream infile("input");
    if (!infile) {
        cout << "Error opening file." << endl;
        return 1;
    }

    string line;
    int numProcesses = 0;
    while (getline(infile, line)) {
        stringstream ss(line);
        ss >> arrival[numProcesses] >> burst[numProcesses];
        numProcesses++;
    }

    infile >> context_switch;
    infile >> quantum;
    infile.close();

    FCFS(arrival, burst, context_switch, finish_time);
    SRT(arrival, burst, context_switch, finish_time);
    RR(arrival, burst, context_switch, quantum, finish_time);

    printGanttChart(finish_time);

    double cpu_utilization = calculateCPUUtilization(finish_time);
    cout << "CPU Utilization: " << cpu_utilization << "%" << endl;

    return 0;
}